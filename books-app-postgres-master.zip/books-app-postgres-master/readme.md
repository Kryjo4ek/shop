#Books test application
This is test application for work.
Working app can be found [here](http://books-app-33.herokuapp.com/).

##Technology stack
Application uses PostgreSQL database.

###Backend:
* Python 3.4.3
* Django 1.8.2
* Tastypie 0.12.0

###Frontend:
* Backbone 1.1.0
* Chaplin 1.0.0
* Handlebars 3.0.3

