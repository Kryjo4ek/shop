from django.contrib import admin

from .models import Book, Profile

admin.site.register(Book)
admin.site.register(Profile)